import "./Hero.css";

import {
    FaGithub,
    FaLinkedin,
    FaEnvelope,
} from "react-icons/fa";

import {
    HiOutlineArrowRight,
    HiOutlineDownload,
} from "react-icons/hi";

function Hero() {
    const handleEmailClick = () => {

        const isMobile =
            /Android|iPhone|iPad|iPod/i.test(
                navigator.userAgent
            );

        if (isMobile) {

            window.location.href =
                "mailto:monishchhuttani2003@gmail.com";

        } else {

            window.open(
                "https://mail.google.com/mail/?view=cm&fs=1&to=monishchhuttani2003@gmail.com",
                "_blank"
            );

        }
    };
    return (
        <section className="hero" id="home">

            <div className="hero-container">

                {/* LEFT */}

                <div className="hero-content">

                    <p className="hero-subtitle">
                        Hi, I'm
                    </p>

                    <h1 className="hero-title">
                        Monish <span>Chhuttani</span>
                    </h1>

                    <h2 className="hero-role">
                        Frontend Developer
                    </h2>

                    <div className="hero-line"></div>

                    <p className="hero-description">
                        I build fast, responsive and
                        user-friendly web applications.
                    </p>

                    <p className="hero-description">
                        I turn ideas into real-world products
                        that solve actual problems.
                    </p>

                    <div className="hero-buttons">

                        <button
                            className="work-btn"
                            onClick={() => {
                                document.getElementById("projects")?.scrollIntoView({
                                    behavior: "smooth"
                                });
                            }}>
                            View My Work
                        </button>

                        <a
                            href="/monish_resume.pdf"
                            download="Monish_Resume.pdf"
                            className="download-btn"
                        >
                            <HiOutlineDownload />
                            Download CV
                        </a>

                    </div>

                    <div className="hero-socials">

                        <a href="https://github.com/monishchhuttani2003-ai">
                            <FaGithub />
                        </a>

                        <a href="https://www.linkedin.com/in/monish-chhuttani-846923265/">
                            <FaLinkedin />
                        </a>

                        <a onClick={handleEmailClick}>
                            <FaEnvelope />
                        </a>

                    </div>

                </div>

                {/* RIGHT */}

                <div className="hero-image-wrapper">

                    <div className="hero-circle"></div>

                    <img
                        src="/images/profile.png"
                        alt="Monish"
                        className="hero-image"
                    />

                    <div className="dots-pattern">
                        {[...Array(35)].map((_, index) => (
                            <span key={index}></span>
                        ))}
                    </div>

                </div>

            </div>

        </section>
    );
}

export default Hero;