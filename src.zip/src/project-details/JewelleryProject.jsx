function JewelleryProject() {
    return (
        <div
            style={{
                padding: "120px 50px",
                textAlign: "center",
            }}
        >
            <h1>
                Jewellery Sales & Stock Tracker
            </h1>
            
            <p>
                Project Detail Page Working ✅
            </p>
        </div>
    );
}
export default JewelleryProject;