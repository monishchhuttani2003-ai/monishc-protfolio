import { useState, useEffect } from "react";
import { HiOutlineDownload, HiOutlineMenuAlt3 } from "react-icons/hi";
import "./Navbar.css";

function Navbar() {
    const [menuOpen, setMenuOpen] = useState(false);
    const [activeSection, setActiveSection] = useState("projects");

    useEffect(() => {
        const handleScroll = () => {
            const sections = [
                "about",
                "skills",
                "projects",
                "education",
                "contact",
            ];

            const scrollPosition = window.scrollY + window.innerHeight / 3;

            sections.forEach((id) => {
                const section = document.getElementById(id);

                if (section) {
                    const sectionTop = section.offsetTop;
                    const sectionHeight = section.offsetHeight;

                    if (
                        scrollPosition >= sectionTop &&
                        scrollPosition < sectionTop + sectionHeight
                    ) {
                        setActiveSection(id);
                    }
                }
            });
        };

        window.addEventListener("scroll", handleScroll);

        handleScroll();

        return () => {
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);

    return (
        <header className="navbar">
            <div className="navbar-container">

                <div className="logo-area">
                    <img
                        src="/images/logo.png"
                        alt="Monish Logo"
                        className="logo-image"
                    />

                    <h2 className="logo-text">
                        <span>MONISH</span> CHHUTTANI
                    </h2>
                </div>

                <ul className="nav-links">

                    <li className={activeSection === "about" ? "active" : ""}>
                        <a href="#about">About</a>
                    </li>

                    <li className={activeSection === "skills" ? "active" : ""}>
                        <a href="#skills">Skills</a>
                    </li>

                    <li className={activeSection === "projects" ? "active" : ""}>
                        <a href="#projects">Projects</a>
                    </li>

                    <li className={activeSection === "education" ? "active" : ""}>
                        <a href="#education">Education</a>
                    </li>

                    <li className={activeSection === "contact" ? "active" : ""}>
                        <a href="#contact">Contact</a>
                    </li>

                </ul>

                <div className="right-section">
                    <a
                        href="/monish_resume.pdf"
                        download="Monish_Resume.pdf"
                        className="cv-btn"
                    >
                        <HiOutlineDownload />
                        <span>My CV</span>
                    </a>

                    <button
                        className="menu-btn"
                        onClick={() => setMenuOpen(!menuOpen)}
                    >
                        <HiOutlineMenuAlt3 />
                    </button>
                </div>

            </div>
            {menuOpen && (
                <div className="mobile-menu">

                    <a href="#home" onClick={() => setMenuOpen(false)}>
                        Home
                    </a>

                    <a href="#about" onClick={() => setMenuOpen(false)}>
                        About
                    </a>

                    <a href="#skills" onClick={() => setMenuOpen(false)}>
                        Skills
                    </a>

                    <a href="#projects" onClick={() => setMenuOpen(false)}>
                        Projects
                    </a>

                    <a href="#education" onClick={() => setMenuOpen(false)}>
                        Education
                    </a>

                    <a href="#contact" onClick={() => setMenuOpen(false)}>
                        Contact
                    </a>

                </div>
            )}

        </header>
    );
}

export default Navbar;